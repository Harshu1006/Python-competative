age=int(input())

if age>=18:
    print("Eligible for voting")
else:
    print("Eligible not for voting")
