#check whether last digit of a number is 4
num = int(input("Enter a number: "))
if num % 10 == 4:
    print("The last digit is 4.")
else:
    print("The last digit is not 4.")
