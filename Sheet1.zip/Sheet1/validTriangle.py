a=int(input())
b=int(input())
c=int(input())

if (a+b+c)==180:
    print("Valid Triagle")
else:
    print("Not a Valid Triangle")
