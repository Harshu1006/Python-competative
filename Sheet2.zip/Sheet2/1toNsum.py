n = int(input("Enter a number: "))
sum_natural = 0
for i in range(1, n + 1):
    sum_natural += i
print("Sum of natural numbers from 1 to", n, "is:", sum_natural)