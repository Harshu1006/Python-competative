num = int(input("Enter a natural number: "))
for i in range(1, 11):
    print(num, "x", i, "=", num * i)