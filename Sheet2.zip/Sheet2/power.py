A = int(input("Enter the base (A): "))
B = int(input("Enter the exponent (B): "))
result = A ** B
print("The value of", A, "^", B, "is", result)