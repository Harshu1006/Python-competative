num = int(input("Enter number: "))
power = int(input("Enter the power: "))
# output = num
# for i in range(1, power):
#     # print(num)
#     output = output * num
# print(f"{num} power {power} is: {output}")

result = num**power
print(f"{num} power {power} is: {result}")